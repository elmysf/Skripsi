package com.example.absensipegawai;

import android.util.Log;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiRepository {

    private ApiServices apiServices;

    public ApiRepository() { apiServices = getRetrofit().create(ApiServices.class);}

    private static Retrofit retrofit = null;


    public static Retrofit getRetrofit(){
        OkHttpClient okHttpClient = UnsafeOkHttpClient.getUnsafeOkHttpClient();

        if (retrofit == null){
            retrofit = new Retrofit.Builder()
                    .baseUrl("https://alga.simdes-bintan.id/rest/")
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

    public void login (String username, String password, final ApiRepositoryCallBack<LoginResponse> callBack){
        apiServices.login(username, password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                Log.d("LOGIN", response.message());
                if (response.isSuccessful()){
                    callBack.onGetResponse(response.body());
                } else {
                    callBack.onGetError();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.d("LOGIN", t.getMessage());
                callBack.onGetError();
            }
        });
    }
}
