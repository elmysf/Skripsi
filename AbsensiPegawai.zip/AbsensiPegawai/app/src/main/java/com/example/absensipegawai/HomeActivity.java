package com.example.absensipegawai;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    //Variables
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    private ApiRepository apiRepository;
    private Button button;
    String userNip;
    LocationRequest locationRequest;
    SharedPreferences sharedPreferences;

    double longitude;
    double latitude;
    Location location;
    Context context;
    LocationManager locationManager;

    private static final long INTERVAL = 1000 * 10;
    private static final long FASTEST_INTERVAL = 1000 * 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        userNip = getIntent().getStringExtra("nip");
        sharedPreferences = getSharedPreferences(LoginActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        String level = sharedPreferences.getString("level", null);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        // Hide Menu untuk user pegawai
        navigationView.setCheckedItem(R.id.nav_absenmasuk);
        if (level.equals("pegawai")) {
            hideMenuItemAtasan();
        }

//        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            checkLocationPermission();
//        }

//        public void createLocationRequest() {
//            locationRequest = new LocationRequest();
//            locationRequest.setInterval(INTERVAL);
//            locationRequest.setFastestInterval(FASTEST_INTERVAL);
//            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
//        }

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        button = (Button) findViewById(R.id.btnmasuk);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                AbsensiKerja();
                //        button.setText(userNip);
            }
        });


//        LocationRequest request = LocationRequest.create();
//        LocationSettingsRequest settingsRequest = new LocationSettingsRequest.Builder()
//                .addLocationRequest(request)
//                .build()
//        LocationServices.getSettingsClient(this/*activity*/)
//                .checkLocationSettings(settingsRequest)
//                .addOnCompleteListener(new OnCompleteListener() {
//                    public void onComplete(Task task) {
//                        if(task.isSuccessful()) {
//                            // ***REQUEST LAST LOCATION HERE***
//                        } else {
//                            Exception e = task.getException()
//                            if (e instanceOf ResolvableApiException) {
//                                // Show the dialog by calling startResolutionForResult(),
//                                // and check the result in onActivityResult()
//                                ((ResolvableApiException)e).startResolutionForResult(HomeActivity.this, REQUEST_CHECK_SETTINGS);
//                            } else {
//                                //Location can not be resolved, inform the user
//                            }
//                        }
//                    }
//                });
    }

//    public boolean checkLocationPermission() {
//        if (ContextCompat.checkSelfPermission(this,
//                Manifest.permission.ACCESS_FINE_LOCATION)
//                != PackageManager.PERMISSION_GRANTED) {
//
//            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
//                    Manifest.permission.ACCESS_FINE_LOCATION)) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
//                        MY_PERMISSIONS_REQUEST_LOCATION);
//            } else {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
//                        MY_PERMISSIONS_REQUEST_LOCATION);
//            }
//            return false;
//        } else {
//            return true;
//        }
//    }

    public void doAbsensiMasuk(){

    }

    public void AbsensiKerja(){
        Intent intent = new Intent(this, AbsensiKerja.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    private void hideMenuItemAtasan(){
        Menu navigationMenu = navigationView.getMenu();
        navigationMenu.findItem(R.id.nav_listpegawai).setVisible(false);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_absenmasuk:
                break;
            case R.id.nav_absenkerja:
                Intent intent = new Intent(HomeActivity.this, AbsensiKerja.class);
                startActivity(intent);
                break;
            case R.id.nav_absenpulang:
                Intent intent2 = new Intent(HomeActivity.this, AbsensiPulang.class);
                startActivity(intent2);
                break;
            case R.id.nav_listpegawai:
                break;
            case R.id.nav_profile:
                Intent intent3 = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(intent3);
                break;
            case R.id.nav_setting:
                Intent intent4 = new Intent(HomeActivity.this, ChangePasswordActivity.class);
                startActivity(intent4);
                break;
            case R.id.nav_off:
                doLogout();
                break;
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    public void doLogout() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        Intent intent5 = new Intent(getBaseContext(), LoginActivity.class);
        String keluar = "Anda telah keluar";
        intent5.putExtra("user_logout", keluar);
        startActivity(intent5);
        Toast.makeText(HomeActivity.this, "Anda telah keluar", Toast.LENGTH_SHORT).show();
    }
}
