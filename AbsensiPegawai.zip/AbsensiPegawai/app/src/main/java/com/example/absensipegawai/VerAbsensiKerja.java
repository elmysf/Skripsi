package com.example.absensipegawai;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class VerAbsensiKerja extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_absensi_kerja);

        drawerLayout = findViewById(R.id.drawer_layout5);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        //buat possisi arah nav item
        navigationView.setCheckedItem(R.id.nav_absenkerja);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_absenmasuk:
                Intent intent = new Intent(VerAbsensiKerja.this, VerAbsensiMasuk.class);
                startActivity(intent);
                break;
            case R.id.nav_absenkerja:
                break;
            case R.id.nav_absenpulang:
                Intent intent2 = new Intent(VerAbsensiKerja.this, AbsensiPulang.class);
                startActivity(intent2);
                break;
            case R.id.nav_profile:
                Intent intent3 = new Intent(VerAbsensiKerja.this, ProfileActivity.class);
                startActivity(intent3);
                break;
            case R.id.nav_setting:
                Intent intent4 = new Intent(VerAbsensiKerja.this, ChangePasswordActivity.class);
                startActivity(intent4);
                break;
            case R.id.nav_off:
                Intent intent5 = new Intent(getBaseContext(), LoginActivity.class);
                String keluar = "Anda telah keluar";
                intent5.putExtra("user_logout", keluar);
                startActivity(intent5);

                Toast.makeText(VerAbsensiKerja.this, "Anda telah keluar", Toast.LENGTH_SHORT).show();
                break;
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}